
const glow = document.querySelector('.cursor-glow');
window.addEventListener('pointermove', e => {
  glow.style.left = e.clientX + 'px';
  glow.style.top = e.clientY + 'px';
});

const reveals = document.querySelectorAll('.reveal');
const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) entry.target.classList.add('visible');
  });
},{threshold:.12});
reveals.forEach(el => observer.observe(el));

document.querySelectorAll('[data-count]').forEach(el => {
  let done = false;
  const obs = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if(entry.isIntersecting && !done){
        done = true;
        const target = +el.dataset.count;
        let start = 0;
        const step = Math.max(1, Math.round(target/40));
        const timer = setInterval(()=>{
          start += step;
          if(start >= target){ start = target; clearInterval(timer); }
          el.textContent = start + (target === 100 ? '' : '');
        },30);
      }
    });
  },{threshold:.6});
  obs.observe(el);
});

const menuBtn = document.querySelector('.menu-btn');
const navLinks = document.querySelector('.nav-links');
menuBtn.addEventListener('click', ()=>{
  const open = navLinks.style.display === 'flex';
  navLinks.style.display = open ? 'none' : 'flex';
  if(!open){
    navLinks.style.position='absolute';
    navLinks.style.top='72px';
    navLinks.style.left='0';
    navLinks.style.right='0';
    navLinks.style.flexDirection='column';
    navLinks.style.padding='18px';
    navLinks.style.background='rgba(7,8,20,.95)';
    navLinks.style.border='1px solid rgba(255,255,255,.1)';
    navLinks.style.borderRadius='18px';
  }
});

const canvas = document.getElementById('particles');
const ctx = canvas.getContext('2d');
let w,h,dpr,particles=[];
function resize(){
  dpr=Math.min(devicePixelRatio||1,2);
  w=innerWidth; h=innerHeight;
  canvas.width=w*dpr; canvas.height=h*dpr;
  canvas.style.width=w+'px'; canvas.style.height=h+'px';
  ctx.setTransform(dpr,0,0,dpr,0,0);
  const count=Math.min(95,Math.floor(w/14));
  particles=Array.from({length:count},()=>({
    x:Math.random()*w,y:Math.random()*h,
    vx:(Math.random()-.5)*.16,vy:(Math.random()-.5)*.16,
    r:Math.random()*1.7+.4
  }));
}
function animate(){
  ctx.clearRect(0,0,w,h);
  for(let i=0;i<particles.length;i++){
    const p=particles[i];
    p.x+=p.vx;p.y+=p.vy;
    if(p.x<0||p.x>w)p.vx*=-1;
    if(p.y<0||p.y>h)p.vy*=-1;
    ctx.beginPath();ctx.arc(p.x,p.y,p.r,0,Math.PI*2);
    ctx.fillStyle='rgba(160,175,255,.38)';ctx.fill();
    for(let j=i+1;j<particles.length;j++){
      const q=particles[j],dx=p.x-q.x,dy=p.y-q.y,dist=Math.hypot(dx,dy);
      if(dist<115){
        ctx.strokeStyle=`rgba(100,110,255,${(1-dist/115)*.075})`;
        ctx.lineWidth=.7;ctx.beginPath();ctx.moveTo(p.x,p.y);ctx.lineTo(q.x,q.y);ctx.stroke();
      }
    }
  }
  requestAnimationFrame(animate);
}
resize();animate();addEventListener('resize',resize);
